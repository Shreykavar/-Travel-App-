package com.example.travelapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.example.travelapp.Domain.itemDomain;
import com.example.travelapp.R;
import com.example.travelapp.databinding.ActivityDetailBinding;
import com.example.travelapp.databinding.ActivityMainBinding;

public class DetailActivity extends BaseActivity {

    ActivityDetailBinding binding;


    private itemDomain object;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        binding=ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        setVariable();
    }

    private void setVariable() {
        binding.titletxt.setText(object.getTitle());
        binding.pricetxt.setText(""+object.getPrice());
        binding.backbtn.setOnClickListener(v -> finish());
        binding.bedtxt.setText(""+object.getBed());
        binding.Durationtxt.setText(object.getDuration());
        binding.distancetxt.setText(object.getDistance());
        binding.descriptiontxt.setText(object.getDescription());
        binding.addresstxt.setText(object.getAddress());
        binding.ratingtxt.setText(object.getScore()+"Rating");
        binding.ratingBar.setRating((float) object.getScore());

        Glide.with(DetailActivity.this)
                .load(object.getPic())
                .into(binding.pic);




        binding.addToCartbtn.setOnClickListener(v -> {

            Intent intent=new Intent(DetailActivity.this,TicketActivity.class);
            intent.putExtra("object",object);
            startActivity(intent);
        });


    }

    private void getIntentExtra() {
        object=(itemDomain) getIntent().getSerializableExtra("object");
    }
}