package com.example.travelapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.travelapp.Domain.itemDomain;
import com.example.travelapp.R;
import com.example.travelapp.databinding.ActivityTicketBinding;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONException;
import org.json.JSONObject;

public class TicketActivity extends AppCompatActivity implements PaymentResultListener {

    private ActivityTicketBinding binding;
    private itemDomain object;

    private Button payButton;
    private EditText amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTicketBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        setVariable();

        amount = findViewById(R.id.amount);
        payButton = findViewById(R.id.paybutton);

        payButton.setOnClickListener(v -> handlePayment());
    }

    private void setVariable() {
        if (object != null) {
            Glide.with(TicketActivity.this)
                    .load(object.getPic())
                    .into(binding.pic);

            Glide.with(TicketActivity.this)
                    .load(object.getTourGuidepic())
                    .into(binding.profile);

            binding.backBtn.setOnClickListener(v -> finish());
            binding.titletxt.setText(object.getTitle());
            binding.Durationtxt.setText(object.getDateTour());
            binding.timetxt.setText(object.getTimeTour());
            binding.tourGuideNameTxt.setText(object.getTourGuideName());

            binding.messageBtn.setOnClickListener(v -> {
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                sendIntent.setData(Uri.parse("sms:" + object.getTourGuidePhone()));
                sendIntent.putExtra("sms_body", "Type your message");
                startActivity(sendIntent);
            });

            binding.callBtn.setOnClickListener(v -> {
                String phone = object.getTourGuidePhone();
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            });
        } else {
            Toast.makeText(this, "Error: Invalid data", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void getIntentExtra() {
        object = (itemDomain) getIntent().getSerializableExtra("object");
    }

    private void handlePayment() {
        String amountText = amount.getText().toString().trim();

        if (amountText.isEmpty()) {
            Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            float amountValue = Float.parseFloat(amountText);
            int amountInPaise = Math.round(amountValue * 100);

            Checkout checkout = new Checkout();
            checkout.setKeyID("rzp_test_km1v0nGqGSqZ1A");

            JSONObject paymentDetails = new JSONObject();
            paymentDetails.put("name", "Developer");
            paymentDetails.put("currency", "INR");
            paymentDetails.put("amount", amountInPaise);

            checkout.open(TicketActivity.this, paymentDetails);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount entered", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            Toast.makeText(this, "Error creating payment details", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPaymentSuccess(String paymentId) {
        Toast.makeText(this, "Payment completed: " + paymentId, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPaymentError(int code, String response) {
        Toast.makeText(this, "Payment failed: " + response, Toast.LENGTH_SHORT).show();
    }
}
