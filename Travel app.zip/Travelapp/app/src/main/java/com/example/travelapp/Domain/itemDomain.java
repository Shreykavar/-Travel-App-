package com.example.travelapp.Domain;

import java.io.Serializable;

public class itemDomain implements Serializable {
    private String title;
    private String address;
    private String description;
    private String duration;
    private String timeTour;
    private String dateTour;
    private String tourGuideName;
    private String pic;
    private int price;
    private int bed;
    private String distance;
    private double score;

    private String tourGuidepic;

private int guest;



    private String tourGuidePhone;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getTimeTour() {
        return timeTour;
    }

    public void setTimeTour(String timeTour) {
        this.timeTour = timeTour;
    }

    public String getDateTour() {
        return dateTour;
    }


    public String getTourGuidePhone() {
        return tourGuidePhone;
    }
    public void setDateTour(String dateTour) {
        this.dateTour = dateTour;
    }

    public String getTourGuideName() {
        return tourGuideName;
    }

    public void setTourGuideName(String tourGuideName) {
        this.tourGuideName = tourGuideName;
    }

    public String getTourGuidepic() {
        return tourGuidepic;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getBed() {
        return bed;
    }

    public int getguest(){
        return bed;
    }

    public int guest(){
        return bed;
    }

    public void setBed(int bed) {
        this.bed = bed;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public String getPic() {  // Ensure this method exists
        return pic;
    }


    public itemDomain(){

    }


}
