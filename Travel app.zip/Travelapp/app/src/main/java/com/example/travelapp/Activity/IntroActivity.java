package com.example.travelapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import com.example.travelapp.databinding.ActivityIntroBinding;

public class IntroActivity extends BaseActivity {
    ActivityIntroBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize the binding object
        binding = ActivityIntroBinding.inflate(getLayoutInflater());

        // Set the content view to the root of the binding
        setContentView(binding.getRoot());

        // Set a click listener for the button to navigate to MainActivity
        binding.introBtn.setOnClickListener(v -> startActivity(new Intent(IntroActivity.this, loginpage.class)));
    }
}
