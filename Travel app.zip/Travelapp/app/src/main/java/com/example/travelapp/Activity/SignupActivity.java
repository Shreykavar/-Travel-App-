package com.example.travelapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.travelapp.R;
import com.example.travelapp.databinding.ActivitySignupBinding;

public class SignupActivity extends AppCompatActivity {

    ActivitySignupBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        binding=ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.signupbutton.setOnClickListener(v -> startActivity(new Intent(SignupActivity.this, loginpage.class)));
        binding.signtologin.setOnClickListener(v -> startActivity(new Intent(SignupActivity.this,loginpage.class)));
    }
}