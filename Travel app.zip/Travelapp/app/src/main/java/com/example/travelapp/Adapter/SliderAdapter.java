package com.example.travelapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.example.travelapp.Domain.Slideritems;
import com.example.travelapp.R;

import java.util.ArrayList;

public class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.SliderViewHolder> {
    private ArrayList<Slideritems> slideritems;
    private ViewPager2 viewPager2;
    private Context context;

    // Runnable for auto-scrolling
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            slideritems.addAll(slideritems); // Ensures seamless infinite scrolling
            notifyDataSetChanged();
        }
    };

    public SliderAdapter(ArrayList<Slideritems> slideritems, ViewPager2 viewPager2) {
        this.slideritems = slideritems;
        this.viewPager2 = viewPager2;
    }

    @NonNull
    @Override
    public SliderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.slider_item_container, parent, false);
        return new SliderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SliderViewHolder holder, int position) {
        holder.setImage(slideritems.get(position));
        if (position == slideritems.size() - 2) {
            viewPager2.post(runnable); // Ensures looping effect near the end of list
        }
    }

    @Override
    public int getItemCount() {
        return slideritems.size();
    }

    public class SliderViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;

        public SliderViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageslide);
        }

        void setImage(Slideritems sliderItem) {
            Glide.with(context)
                    .load(sliderItem.getUrl())
                    .into(imageView);
        }
    }
}
