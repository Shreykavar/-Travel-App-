package com.example.travelapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.travelapp.R;
import com.example.travelapp.databinding.ActivityFooterBinding;
import com.example.travelapp.databinding.ActivityIntroBinding;

public class footer extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }
}
