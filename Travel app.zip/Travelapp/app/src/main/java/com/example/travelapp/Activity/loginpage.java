package com.example.travelapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.travelapp.R;
import com.example.travelapp.databinding.ActivityLoginpageBinding;

public class loginpage extends AppCompatActivity {

    ActivityLoginpageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        binding=ActivityLoginpageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.loginButton.setOnClickListener(v -> startActivity(new Intent(loginpage.this,MainActivity.class)));
        binding.signupbtn.setOnClickListener(v -> startActivity(new Intent(loginpage.this,SignupActivity.class)));

    }
}